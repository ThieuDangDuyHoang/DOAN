package doan1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class InHoaDon extends JFrame implements ActionListener, Printable {

	private JTextArea txtHoaDon;
	private JButton btnPrint, btnClose;
	private String maPhong, maKhach;

	public InHoaDon(String maPhong, String maKhach) {
		this.maPhong = maPhong;
		this.maKhach = maKhach;

		setTitle("In Hóa Đơn Thuê Phòng");
		setSize(650, 750);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(new Color(245, 245, 245));

		// Header
		JLabel lblTitle = new JLabel("HÓA ĐƠN THUÊ PHÒNG", SwingConstants.CENTER);
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblTitle.setForeground(new Color(0, 102, 204));
		panel.add(lblTitle, BorderLayout.NORTH);

		// Nội dung hóa đơn
		txtHoaDon = new JTextArea();
		txtHoaDon.setFont(new Font("Monospaced", Font.PLAIN, 14));
		txtHoaDon.setEditable(false);
		txtHoaDon.setMargin(new Insets(15, 20, 15, 20));
		JScrollPane scroll = new JScrollPane(txtHoaDon);
		panel.add(scroll, BorderLayout.CENTER);

		// Buttons
		JPanel btnPanel = new JPanel();
		btnPrint = new JButton("🖨 In Hóa Đơn");
		btnPrint.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnPrint.setBackground(new Color(40, 167, 69));
		btnPrint.setForeground(Color.white);
		btnPrint.addActionListener(this);

		btnClose = new JButton("Đóng");
		btnClose.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnClose.addActionListener(this);

		btnPanel.add(btnPrint);
		btnPanel.add(btnClose);
		panel.add(btnPanel, BorderLayout.SOUTH);

		add(panel);

		// Tải dữ liệu hóa đơn
		loadHoaDon();
		setVisible(true);
	}

	private void loadHoaDon() {
		StringBuilder sb = new StringBuilder();
		sb.append("                  CHO THUÊ PHÒNG TRỌ\n");
		sb.append("              K133/16 NGUYỄN VĂN LINH\n");
		sb.append("                   SĐT: 0123 456 789\n");
		sb.append("==============================================\n\n");
		sb.append("                  HÓA ĐƠN THUÊ PHÒNG\n");
		sb.append("==============================================\n\n");

		try (Connection conn = DriverManager.getConnection(
				"jdbc:sqlserver://localhost:1433;databaseName=DOAN1;integratedSecurity=true;encrypt=false;")) {

			// Lấy thông tin phòng + khách
			String sql = "SELECT p.MaPhong, p.TenPhong, p.DienTich, p.GiaThue, p.TrangThai, "
					+ "k.HoTen, k.SoDienThoai, k.Email " + "FROM Phong p JOIN KhachThue k ON p.MaKhach = k.MaKhach "
					+ "WHERE p.MaPhong = ? AND k.MaKhach = ?";

			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, maPhong);
			pst.setString(2, maKhach);

			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

				sb.append("Mã phòng       : ").append(rs.getString("MaPhong")).append("\n");
				sb.append("Tên phòng      : ").append(rs.getString("TenPhong")).append("\n");
				sb.append("Diện tích      : ").append(rs.getDouble("DienTich")).append(" m²\n");
				sb.append("Giá thuê       : ").append(String.format("%,.0f", rs.getBigDecimal("GiaThue")))
						.append(" VNĐ\n");
				sb.append("Trạng thái     : ").append(rs.getString("TrangThai")).append("\n\n");

				sb.append("Khách thuê     : ").append(rs.getString("HoTen")).append("\n");
				sb.append("SĐT            : ").append(rs.getString("SoDienThoai")).append("\n");
				sb.append("Email          : ").append(rs.getString("Email") != null ? rs.getString("Email") : "")
						.append("\n\n");

				sb.append("Ngày lập hóa đơn: ").append(sdf.format(new Date())).append("\n");
				sb.append("==============================================\n");
				sb.append("TỔNG TIỀN      : ").append(String.format("%,.0f", rs.getBigDecimal("GiaThue")))
						.append(" VNĐ\n");
				sb.append("==============================================\n\n");
				sb.append("Cảm ơn quý khách đã sử dụng dịch vụ!\n");
				sb.append("Hóa đơn này có giá trị thanh toán.");

			} else {
				sb.append("Không tìm thấy thông tin phòng hoặc khách thuê!");
			}

		} catch (Exception ex) {
			sb.append("Lỗi khi tải dữ liệu: ").append(ex.getMessage());
		}

		txtHoaDon.setText(sb.toString());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnPrint) {
			printHoaDon();
		} else if (e.getSource() == btnClose) {
			dispose();
		}
	}

	private void printHoaDon() {
		PrinterJob job = PrinterJob.getPrinterJob();
		job.setPrintable(this);

		if (job.printDialog()) {
			try {
				job.print();
				JOptionPane.showMessageDialog(this, "In hóa đơn thành công!", "Thông báo",
						JOptionPane.INFORMATION_MESSAGE);
			} catch (PrinterException ex) {
				JOptionPane.showMessageDialog(this, "Lỗi khi in: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	@Override
	public int print(Graphics g, PageFormat pf, int page) throws PrinterException {
		if (page > 0)
			return NO_SUCH_PAGE;

		Graphics2D g2d = (Graphics2D) g;
		g2d.translate(pf.getImageableX(), pf.getImageableY());

		// In nội dung JTextArea
		txtHoaDon.print(g2d);

		return PAGE_EXISTS;
	}

	// Phương thức tiện ích để gọi từ các form khác
	public static void showHoaDon(String maPhong, String maKhach) {
		new InHoaDon(maPhong, maKhach);
	}
}