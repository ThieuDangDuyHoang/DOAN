package doan1;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class thongtinroom extends JFrame implements ActionListener {

	// Thông tin Khách thuê
	JTextField maKhachText, hoTenText, ngaySinhText, soDienThoaiText, emailText, diaChiText;
	// Thông tin Phòng thuê
	JTextField maPhongText, tenPhongText, dienTichText, giaThueText;
	Choice trangThaiCho;

	JButton submit, cancel; // ← Thêm nút cancel

	thongtinroom() {
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(245, 245, 245));
		add(panel);

		JLabel heading = new JLabel("QUẢN LÝ ĐỒNG BỘ PHÒNG & KHÁCH THUÊ");
		heading.setBounds(200, 20, 520, 35);
		heading.setFont(new Font("Tahoma", Font.BOLD, 22));
		heading.setForeground(new Color(0, 102, 204));
		panel.add(heading);

		// ================= KHÁCH THUÊ =================
		JLabel khachHeading = new JLabel("Thông tin Khách thuê");
		khachHeading.setBounds(50, 70, 250, 25);
		khachHeading.setFont(new Font("Tahoma", Font.BOLD, 16));
		panel.add(khachHeading);

		addLabelAndField(panel, "Mã khách (*)", maKhachText = new JTextField(), 50, 110);
		addLabelAndField(panel, "Họ tên (*)", hoTenText = new JTextField(), 50, 150);
		addLabelAndField(panel, "Ngày sinh (YYYY-MM-DD)", ngaySinhText = new JTextField(), 50, 190);
		addLabelAndField(panel, "Số điện thoại", soDienThoaiText = new JTextField(), 50, 230);
		addLabelAndField(panel, "Email", emailText = new JTextField(), 50, 270);
		addLabelAndField(panel, "Địa chỉ", diaChiText = new JTextField(), 50, 310);

		// Đường phân cách
		JPanel separator = new JPanel();
		separator.setBounds(425, 75, 2, 280);
		separator.setBackground(new Color(200, 200, 200));
		panel.add(separator);

		// ================= PHÒNG THUÊ =================
		JLabel phongHeading = new JLabel("Thông tin Phòng thuê");
		phongHeading.setBounds(470, 70, 250, 25);
		phongHeading.setFont(new Font("Tahoma", Font.BOLD, 16));
		panel.add(phongHeading);

		addLabelAndField(panel, "Mã phòng (*)", maPhongText = new JTextField(), 470, 110);
		addLabelAndField(panel, "Tên phòng (*)", tenPhongText = new JTextField(), 470, 150);
		addLabelAndField(panel, "Diện tích (m²)", dienTichText = new JTextField(), 470, 190);
		addLabelAndField(panel, "Giá thuê (VNĐ)", giaThueText = new JTextField(), 470, 230);

		JLabel trangThaiLabel = new JLabel("Trạng thái");
		trangThaiLabel.setBounds(470, 270, 100, 25);
		panel.add(trangThaiLabel);

		trangThaiCho = new Choice();
		trangThaiCho.add("Trả trước");
		trangThaiCho.add("Trả sau");
		trangThaiCho.setBounds(580, 270, 220, 25);
		panel.add(trangThaiCho);

		// ================= NÚT THAO TÁC =================
		submit = new JButton("Lưu & Đồng bộ thông tin");
		submit.setBounds(280, 380, 240, 40);
		submit.setBackground(new Color(40, 167, 69));
		submit.setForeground(Color.white);
		submit.setFont(new Font("Tahoma", Font.BOLD, 14));
		submit.addActionListener(this);
		panel.add(submit);

		// === NÚT CANCEL ĐÃ ĐƯỢC THÊM ===
		cancel = new JButton("Hủy");
		cancel.setBounds(540, 380, 120, 40);
		cancel.setBackground(new Color(220, 53, 69));
		cancel.setForeground(Color.white);
		cancel.setFont(new Font("Tahoma", Font.BOLD, 14));
		cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				menu m = new menu();
				m.Reception();
				dispose();

			}
		});
		panel.add(cancel);

		setTitle("Quản Lý Phòng & Khách Thuê");
		setSize(880, 500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setVisible(true);
	}

	private void addLabelAndField(JPanel panel, String labelText, JTextField field, int x, int y) {
		JLabel label = new JLabel(labelText);
		label.setBounds(x, y, 140, 25);
		panel.add(label);
		field.setBounds(x + 150, y, 220, 25);
		panel.add(field);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == cancel) {
			int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn hủy thao tác này?", "Xác nhận hủy",
					JOptionPane.YES_NO_OPTION);

			if (confirm == JOptionPane.YES_OPTION) {
				menu m = new menu();
				m.Reception();
				dispose();
			}
			return;
		}

		if (e.getSource() != submit)
			return;

		// ... (phần code xử lý Submit giữ nguyên như cũ)
		String maKhach = maKhachText.getText().trim();
		String hoTen = hoTenText.getText().trim();
		String ngaySinh = ngaySinhText.getText().trim();
		String sdt = soDienThoaiText.getText().trim();
		String email = emailText.getText().trim();
		String diaChi = diaChiText.getText().trim();
		String maPhong = maPhongText.getText().trim();
		String tenPhong = tenPhongText.getText().trim();
		String dienTichStr = dienTichText.getText().trim();
		String giaThueStr = giaThueText.getText().trim();
		String trangThai = trangThaiCho.getSelectedItem();

		if (maKhach.isEmpty() || hoTen.isEmpty() || maPhong.isEmpty() || tenPhong.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ các trường bắt buộc (*)", "Cảnh báo",
					JOptionPane.WARNING_MESSAGE);
			return;
		}

		Connection conn = null;
		try {
			conn = DriverManager.getConnection(
					"jdbc:sqlserver://localhost:1433;databaseName=DOAN1;integratedSecurity=true;encrypt=false;");
			conn.setAutoCommit(false);

			// 1. Insert Phòng
			String sqlPhong = "INSERT INTO Phong (MaPhong, TenPhong, DienTich, GiaThue, TrangThai, MaKhach) "
					+ "VALUES (?, ?, ?, ?, ?, NULL)";
			PreparedStatement pstPhong = conn.prepareStatement(sqlPhong);
			pstPhong.setString(1, maPhong);
			pstPhong.setString(2, tenPhong);
			pstPhong.setDouble(3, dienTichStr.isEmpty() ? 0 : Double.parseDouble(dienTichStr));
			pstPhong.setBigDecimal(4, giaThueStr.isEmpty() ? null : new BigDecimal(giaThueStr));
			pstPhong.setString(5, trangThai);
			pstPhong.executeUpdate();

			// 2. Insert Khách thuê
			String sqlKhach = "INSERT INTO KhachThue (MaKhach, HoTen, NgaySinh, SoDienThoai, Email, DiaChi, MaPhong) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement pstKhach = conn.prepareStatement(sqlKhach);
			pstKhach.setString(1, maKhach);
			pstKhach.setString(2, hoTen);
			pstKhach.setString(3, ngaySinh.isEmpty() ? null : ngaySinh);
			pstKhach.setString(4, sdt);
			pstKhach.setString(5, email);
			pstKhach.setString(6, diaChi);
			pstKhach.setString(7, maPhong);
			pstKhach.executeUpdate();

			// 3. Cập nhật MaKhach vào bảng Phòng
			String sqlUpdate = "UPDATE Phong SET MaKhach = ? WHERE MaPhong = ?";
			PreparedStatement pstUpdate = conn.prepareStatement(sqlUpdate);
			pstUpdate.setString(1, maKhach);
			pstUpdate.setString(2, maPhong);
			pstUpdate.executeUpdate();

			conn.commit();
			JOptionPane.showMessageDialog(this, "Lưu thông tin thành công!", "Thành công",
					JOptionPane.INFORMATION_MESSAGE);

			menu m = new menu();
			m.Reception();
			dispose();

		} catch (Exception ex) {
			try {
				if (conn != null)
					conn.rollback();
			} catch (Exception r) {
			}
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception ex) {
			}
		}
	}

	public static void main(String[] args) {
		new thongtinroom();
	}
}