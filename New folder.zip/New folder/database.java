package doan1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class database {

	Connection connection;
	Statement statement;

	public database() {
		try {

			String url = "jdbc:sqlserver://localhost:1433;" + "databaseName=DOAN1;" + "encrypt=false;"
					+ "trustServerCertificate=true;" + "integratedSecurity=true;";

			connection = DriverManager.getConnection(url);
			statement = connection.createStatement();

			System.out.println("✅ Kết nối Database thành công ");

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Lỗi kết nối Database!");
		}
	}
}