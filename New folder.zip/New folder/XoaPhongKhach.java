package doan1;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class XoaPhongKhach extends JFrame implements ActionListener {

	private JTextField txtMaPhong;
	private JButton btnXoa, btnHuy;
	private JTextArea txtThongTin;

	public XoaPhongKhach() {
		setTitle("Xóa Phòng & Khách Thuê");
		setSize(620, 520);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(245, 245, 245));
		add(panel);

		JLabel lblTitle = new JLabel("XÓA PHÒNG VÀ THÔNG TIN KHÁCH THUÊ");
		lblTitle.setBounds(120, 20, 400, 35);
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblTitle.setForeground(new Color(220, 53, 69));
		panel.add(lblTitle);

		JLabel lblMaPhong = new JLabel("Nhập Mã Phòng cần xóa:");
		lblMaPhong.setBounds(50, 80, 200, 25);
		panel.add(lblMaPhong);

		txtMaPhong = new JTextField();
		txtMaPhong.setBounds(250, 80, 200, 30);
		panel.add(txtMaPhong);

		btnXoa = new JButton("XÓA PHÒNG");
		btnXoa.setBounds(180, 130, 120, 40);
		btnXoa.setBackground(new Color(220, 53, 69));
		btnXoa.setForeground(Color.WHITE);
		btnXoa.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnXoa.addActionListener(this);
		panel.add(btnXoa);

		btnHuy = new JButton("Hủy");
		btnHuy.setBounds(320, 130, 100, 40);
		btnHuy.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnHuy.addActionListener(this);
		panel.add(btnHuy);

		// Khu vực hiển thị thông tin trước khi xóa
		txtThongTin = new JTextArea();
		txtThongTin.setBounds(50, 190, 500, 220);
		txtThongTin.setEditable(false);
		txtThongTin.setFont(new Font("Monospaced", Font.PLAIN, 14));
		txtThongTin.setBorder(BorderFactory.createTitledBorder("Thông tin phòng & khách"));
		panel.add(txtThongTin);

		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnHuy) {
			dispose();
			return;
		}

		if (e.getSource() == btnXoa) {
			String maPhong = txtMaPhong.getText().trim();

			if (maPhong.isEmpty()) {
				JOptionPane.showMessageDialog(this, "Vui lòng nhập Mã Phòng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
				return;
			}

			// Hiển thị thông tin trước khi xóa
			hienThiThongTin(maPhong);

			int confirm = JOptionPane.showConfirmDialog(this,
					"Bạn có chắc chắn muốn xóa phòng " + maPhong + " và toàn bộ thông tin khách thuê liên quan?\n"
							+ "Hành động này KHÔNG THỂ HOÀN TÁC!",
					"Xác nhận xóa", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE);

			if (confirm != JOptionPane.YES_OPTION)
				return;

			try (Connection conn = DriverManager.getConnection(
					"jdbc:sqlserver://localhost:1433;databaseName=DOAN1;integratedSecurity=true;encrypt=false;")) {

				conn.setAutoCommit(false);

				// Xóa Hợp đồng (nếu có)
				String sqlHopDong = "DELETE FROM hopdong WHERE MaPhong = ?";
				PreparedStatement pstHD = conn.prepareStatement(sqlHopDong);
				pstHD.setString(1, maPhong);
				pstHD.executeUpdate();

				// Xóa Phòng
				String sqlPhong = "DELETE FROM Phong WHERE MaPhong = ?";
				PreparedStatement pstPhong = conn.prepareStatement(sqlPhong);
				pstPhong.setString(1, maPhong);
				pstPhong.executeUpdate();

				// Xóa Khách thuê
				String sqlKhach = "DELETE FROM KhachThue WHERE MaPhong = ?";
				PreparedStatement pstKhach = conn.prepareStatement(sqlKhach);
				pstKhach.setString(1, maPhong);
				pstKhach.executeUpdate();

				conn.commit();

				JOptionPane.showMessageDialog(this, "Xóa phòng thành công!", "Thành công",
						JOptionPane.INFORMATION_MESSAGE);

				txtMaPhong.setText("");
				txtThongTin.setText("");

			} catch (SQLException ex) {
				ex.printStackTrace();
				JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	private void hienThiThongTin(String maPhong) {
		StringBuilder info = new StringBuilder();
		try (Connection conn = DriverManager.getConnection(
				"jdbc:sqlserver://localhost:1433;databaseName=DOAN1;integratedSecurity=true;encrypt=false;")) {

			String sql = "SELECT p.TenPhong, p.GiaThue, k.HoTen, k.SoDienThoai "
					+ "FROM Phong p LEFT JOIN KhachThue k ON p.MaKhach = k.MaKhach " + "WHERE p.MaPhong = ?";

			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, maPhong);
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				info.append("Mã phòng     : ").append(maPhong).append("\n");
				info.append("Tên phòng    : ").append(rs.getString("TenPhong")).append("\n");
				info.append("Giá thuê     : ").append(String.format("%,.0f", rs.getBigDecimal("GiaThue")))
						.append(" VNĐ\n");
				info.append("Khách thuê   : ").append(rs.getString("HoTen") != null ? rs.getString("HoTen") : "Chưa có")
						.append("\n");
				info.append("SĐT          : ")
						.append(rs.getString("SoDienThoai") != null ? rs.getString("SoDienThoai") : "").append("\n");
			} else {
				info.append("Không tìm thấy phòng này!");
			}
		} catch (Exception ex) {
			info.append("Lỗi khi tải thông tin: ").append(ex.getMessage());
		}
		txtThongTin.setText(info.toString());
	}

	public static void main(String[] args) {
		new XoaPhongKhach();
	}
}