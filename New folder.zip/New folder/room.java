package doan1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class room extends JFrame implements ActionListener {
	JLabel heading, meternumText, customerName, meterNum, address, city, state, email, phone;
	JButton next, cancel;
	TextField nameText, addressText, cityText, stateText, emailText, phoneText;

	public room() {
		super("New Customer");
		setSize(700, 500);
		setLocation(400, 200);

		ImageIcon icon = new ImageIcon("D:/ảnh/newcustomer.png");
		Image scaledImage = icon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH);
		ImageIcon chinhanh = new ImageIcon(scaledImage);
		JLabel anh = new JLabel(chinhanh);
		anh.setBounds(400, 90, 250, 270);
		add(anh);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(181, 181, 181));
		add(panel);

		heading = new JLabel("New Customer");
		heading.setBounds(180, 10, 200, 20);
		heading.setFont(new Font("Tahoma", Font.BOLD, 20));
		panel.add(heading);

		customerName = new JLabel("Customer Name");
		customerName.setBounds(50, 80, 100, 20);
		panel.add(customerName);

		nameText = new TextField();
		nameText.setBounds(180, 80, 150, 20);
		panel.add(nameText);

		meterNum = new JLabel("Meter Number");
		meterNum.setBounds(50, 120, 100, 20);
		panel.add(meterNum);

		meternumText = new JLabel("");
		meternumText.setBounds(180, 120, 150, 20);
		panel.add(meternumText);

		Random ran = new Random();
		long number = ran.nextLong() % 1000000;
		meternumText.setText("" + Math.abs(number));

		address = new JLabel("Address ");
		address.setBounds(50, 160, 100, 20);
		panel.add(address);

		addressText = new TextField();
		addressText.setBounds(180, 160, 150, 20);
		panel.add(addressText);

		city = new JLabel("Date ");
		city.setBounds(50, 200, 100, 20);
		panel.add(city);

		cityText = new TextField();
		cityText.setBounds(180, 200, 150, 20);
		panel.add(cityText);

		email = new JLabel("Email ");
		email.setBounds(50, 240, 100, 20);
		panel.add(email);

		emailText = new TextField();
		emailText.setBounds(180, 240, 150, 20);
		panel.add(emailText);

		phone = new JLabel("Phone ");
		phone.setBounds(50, 280, 100, 20);
		panel.add(phone);

		phoneText = new TextField();
		phoneText.setBounds(180, 280, 150, 20);
		panel.add(phoneText);

		next = new JButton("Next");
		next.setBounds(120, 380, 100, 25);
		next.setBackground(Color.black);
		next.setForeground(Color.white);
		next.addActionListener(this);
		panel.add(next);

		cancel = new JButton("Cancel");
		cancel.setBounds(260, 380, 100, 25);
		cancel.setBackground(Color.black);
		cancel.setForeground(Color.white);
		cancel.addActionListener(this);
		panel.add(cancel);

		setLayout(new BorderLayout());
		add(panel, "Center");
		setVisible(true);
		next.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String name = nameText.getText().trim();
				String number = meternumText.getText();
				String diachi = addressText.getText();
				String ngaythang = cityText.getText();
				String email = emailText.getText();
				String phone = phoneText.getText();

				try {

					Connection conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;"
							+ "databaseName=DOAN1;" + "integratedSecurity=true;" + "encrypt=false;");
					String sql = "INSERT INTO KhachThue (Hoten, MaKhach, ngaysinh, sodienthoai,email,diachi) VALUES (?, ?, ?, ?,?,?)";
					PreparedStatement stmt = conn.prepareStatement(sql);

					stmt.setString(1, name);
					stmt.setString(2, number);
					stmt.setDate(3, java.sql.Date.valueOf(ngaythang));
					stmt.setString(4, phone);
					stmt.setString(5, email);
					stmt.setString(6, diachi);

					stmt.executeUpdate();

					System.out.println("Đã lưu thông tin vào database!");
					stmt.close();
					conn.close();

				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});

		cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				menu m = new menu();
				m.Reception();
				room.this.dispose();
			}
		});
	}

	public static void main(String[] args) {
		new room();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}
}