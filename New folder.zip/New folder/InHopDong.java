package doan1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class InHopDong extends JFrame implements ActionListener, Printable {

	private JTextArea txtHopDong;
	private JButton btnIn, btnDong;
	private String maHopDong;

	public InHopDong(String maHopDong) {
		this.maHopDong = maHopDong;

		setTitle("In Hợp Đồng Thuê Phòng");
		setSize(750, 850);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
		mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
		mainPanel.setBackground(new Color(245, 245, 245));

		JLabel lblTitle = new JLabel("HỢP ĐỒNG THUÊ PHÒNG", SwingConstants.CENTER);
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblTitle.setForeground(new Color(0, 102, 204));
		mainPanel.add(lblTitle, BorderLayout.NORTH);

		txtHopDong = new JTextArea();
		txtHopDong.setFont(new Font("Monospaced", Font.PLAIN, 15));
		txtHopDong.setEditable(false);
		txtHopDong.setMargin(new Insets(20, 25, 20, 25));
		txtHopDong.setBackground(Color.WHITE);

		JScrollPane scrollPane = new JScrollPane(txtHopDong);
		mainPanel.add(scrollPane, BorderLayout.CENTER);

		JPanel panelButton = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
		panelButton.setBackground(new Color(245, 245, 245));

		btnIn = new JButton("🖨 In Hợp Đồng");
		btnIn.setPreferredSize(new Dimension(180, 45));
		btnIn.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnIn.setBackground(new Color(40, 167, 69));
		btnIn.setForeground(Color.WHITE);
		btnIn.addActionListener(this);

		btnDong = new JButton("Đóng");
		btnDong.setPreferredSize(new Dimension(120, 45));
		btnDong.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnDong.addActionListener(this);

		panelButton.add(btnIn);
		panelButton.add(btnDong);
		mainPanel.add(panelButton, BorderLayout.SOUTH);

		add(mainPanel);

		loadDuLieuHopDong();
		setVisible(true);
	}

	private void loadDuLieuHopDong() {
		StringBuilder hd = new StringBuilder();

		hd.append("                  CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM\n");
		hd.append("                       Độc lập - Tự do - Hạnh phúc\n");
		hd.append("========================================================\n\n");
		hd.append("                           HỢP ĐỒNG THUÊ PHÒNG\n");
		hd.append("========================================================\n\n");

		try (Connection conn = DriverManager.getConnection(
				"jdbc:sqlserver://localhost:1433;databaseName=DOAN1;integratedSecurity=true;encrypt=false;")) {

			String sql = "SELECT h.MaHopDong, h.SoThang, h.DieuKhoan, " + "p.MaPhong, p.TenPhong, p.GiaThue, "
					+ "k.HoTen, k.SoDienThoai, k.Email " + "FROM HopDong h "
					+ "LEFT JOIN Phong p ON h.MaPhong = p.MaPhong " + "LEFT JOIN KhachThue k ON h.MaKhach = k.MaKhach "
					+ "WHERE h.MaHopDong = ?";
			System.out.println("[" + maHopDong + "]");

			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, maHopDong);
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

				hd.append("Mã hợp đồng   : ").append(rs.getString("MaHopDong")).append("\n");
				hd.append("Mã phòng      : ").append(rs.getString("MaPhong")).append("\n");
				hd.append("Tên phòng     : ").append(rs.getString("TenPhong")).append("\n");
				hd.append("Giá thuê      : ").append(String.format("%,.0f", rs.getBigDecimal("GiaThue")))
						.append(" VNĐ/tháng\n\n");

				hd.append("BÊN THUÊ:\n");
				hd.append("Họ tên        : ").append(rs.getString("HoTen")).append("\n");
				hd.append("SĐT           : ").append(rs.getString("SoDienThoai")).append("\n");
				hd.append("Email         : ").append(rs.getString("Email") != null ? rs.getString("Email") : "")
						.append("\n\n");

				hd.append("Thời gian thuê:\n");

				hd.append("Số tháng      : ").append(rs.getInt("SoThang")).append(" tháng\n\n");

				hd.append("ĐIỀU KHOẢN:\n");
				hd.append(rs.getString("DieuKhoan") != null ? rs.getString("DieuKhoan")
						: "Các bên cam kết thực hiện đúng theo quy định pháp luật.").append("\n\n");

				hd.append("Ngày lập hợp đồng: ").append(sdf.format(new Date())).append("\n");
				hd.append("========================================================\n");
				hd.append("          Hai bên đã đọc kỹ và đồng ý với tất cả các điều khoản.\n");
				hd.append("========================================================\n\n");
				hd.append("                  Bên cho thuê                          Bên thuê\n");
				hd.append("             (Ký và ghi rõ họ tên)                 (Ký và ghi rõ họ tên)");

			} else {
				hd.append("Không tìm thấy hợp đồng với mã: ").append(maHopDong);
			}

		} catch (Exception ex) {
			hd.append("Lỗi khi tải dữ liệu: ").append(ex.getMessage());
		}

		txtHopDong.setText(hd.toString());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnIn) {
			printHopDong();
		} else if (e.getSource() == btnDong) {
			dispose();
		}
	}

	private void printHopDong() {
		PrinterJob job = PrinterJob.getPrinterJob();
		job.setPrintable(this);

		if (job.printDialog()) {
			try {
				job.print();
				JOptionPane.showMessageDialog(this, "In hợp đồng thành công!", "Thành công",
						JOptionPane.INFORMATION_MESSAGE);
			} catch (PrinterException ex) {
				JOptionPane.showMessageDialog(this, "Lỗi khi in: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	@Override
	public int print(Graphics g, PageFormat pf, int page) throws PrinterException {
		if (page > 0)
			return NO_SUCH_PAGE;

		Graphics2D g2d = (Graphics2D) g;
		g2d.translate(pf.getImageableX(), pf.getImageableY());
		txtHopDong.print(g2d);

		return PAGE_EXISTS;
	}

	// Phương thức gọi nhanh
	public static void showInHopDong(String maHopDong) {
		new InHopDong(maHopDong);
	}
}