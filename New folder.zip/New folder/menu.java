package doan1;

import java.awt.Color;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class menu extends JFrame {

	void Reception() {
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(280, 5, 1238, 820);
		panel.setBackground(new Color(3, 45, 48));
		add(panel);

		JPanel panel1 = new JPanel();
		panel1.setLayout(null);
		panel1.setBounds(5, 5, 270, 820);
		panel1.setBackground(new Color(3, 45, 48));
		add(panel1);

		// Hình nền lớn
		ImageIcon i111 = new ImageIcon("D:/ảnh/pic.jpg");
		Image i22 = i111.getImage().getScaledInstance(800, 800, Image.SCALE_DEFAULT);
		JLabel label11 = new JLabel(new ImageIcon(i22));
		label11.setBounds(300, 20, 800, 800);
		panel.add(label11);

		// Hình nhỏ bên trái
		ImageIcon i11 = new ImageIcon("D:/ảnh/pic.jpg");
		Image i2 = i11.getImage().getScaledInstance(250, 250, Image.SCALE_DEFAULT);
		JLabel label1 = new JLabel(new ImageIcon(i2));
		label1.setBounds(5, 530, 250, 250);
		panel1.add(label1);

		// ==================== CÁC NÚT CHỨC NĂNG ====================

		JButton btnNCF = new JButton("Tạo hợp đồng");
		btnNCF.setBounds(30, 30, 200, 30);
		btnNCF.setBackground(Color.BLACK);
		btnNCF.setForeground(Color.WHITE);
		panel1.add(btnNCF);
		btnNCF.addActionListener(e -> {
			new hopdong();
			menu.this.dispose();
		});

		JButton btnRoom = new JButton("Tạo Phòng");
		btnRoom.setBounds(30, 70, 200, 30);
		btnRoom.setBackground(Color.BLACK);
		btnRoom.setForeground(Color.WHITE);
		panel1.add(btnRoom);
		btnRoom.addActionListener(e -> {
			menu.this.dispose();
			new thongtinroom();
		});

		// ==================== NÚT XÓA PHÒNG ====================
		JButton btnXoaPhong = new JButton("Xóa Phòng");
		btnXoaPhong.setBounds(30, 110, 200, 30);
		btnXoaPhong.setBackground(Color.BLACK); // ← Đã đổi thành đen
		btnXoaPhong.setForeground(Color.WHITE);
		panel1.add(btnXoaPhong);

		btnXoaPhong.addActionListener(e -> {
			new XoaPhongKhach();
		});

		JButton btnDepartment = new JButton("Tạo hóa đơn");
		btnDepartment.setBounds(30, 150, 200, 30);
		btnDepartment.setBackground(Color.BLACK);
		btnDepartment.setForeground(Color.WHITE);
		panel1.add(btnDepartment);
		btnDepartment.addActionListener(e -> {
			new hoadon();
			menu.this.dispose();
		});

		JButton btnAEI = new JButton("Danh sách khách thuê");
		btnAEI.setBounds(30, 190, 200, 30);
		btnAEI.setBackground(Color.BLACK);
		btnAEI.setForeground(Color.WHITE);
		panel1.add(btnAEI);
		btnAEI.addActionListener(e -> {
			new dsach();
			dispose();
		});

		// ==================== IN HÓA ĐƠN ====================
		JButton btnCI = new JButton("In Hóa Đơn");
		btnCI.setBounds(30, 230, 200, 30);
		btnCI.setBackground(Color.BLACK);
		btnCI.setForeground(Color.WHITE);
		panel1.add(btnCI);

		btnCI.addActionListener(e -> {
			String maPhong = JOptionPane.showInputDialog(this, "Nhập Mã Phòng cần in hóa đơn:", "In Hóa Đơn",
					JOptionPane.PLAIN_MESSAGE);

			if (maPhong == null || maPhong.trim().isEmpty())
				return;

			maPhong = maPhong.trim();

			try (Connection conn = DriverManager.getConnection(
					"jdbc:sqlserver://localhost:1433;databaseName=DOAN1;integratedSecurity=true;encrypt=false;")) {

				String sql = "SELECT MaKhach FROM Phong WHERE MaPhong = ?";
				PreparedStatement pst = conn.prepareStatement(sql);
				pst.setString(1, maPhong);
				ResultSet rs = pst.executeQuery();

				if (rs.next()) {
					String maKhach = rs.getString("MaKhach");
					if (maKhach != null && !maKhach.trim().isEmpty()) {
						InHoaDon.showHoaDon(maPhong, maKhach);
					} else {
						JOptionPane.showMessageDialog(this, "Phòng này chưa có khách thuê!", "Thông báo",
								JOptionPane.WARNING_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(this, "Không tìm thấy phòng: " + maPhong, "Lỗi",
							JOptionPane.ERROR_MESSAGE);
				}
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
			}
		});

		// ==================== IN HỢP ĐỒNG ====================
		JButton btnInHopDong = new JButton("In Hợp Đồng");
		btnInHopDong.setBounds(30, 270, 200, 30);
		btnInHopDong.setBackground(Color.BLACK);
		btnInHopDong.setForeground(Color.WHITE);
		panel1.add(btnInHopDong);

		btnInHopDong.addActionListener(e -> {
			String maHopDong = JOptionPane.showInputDialog(this, "Nhập Mã Hợp Đồng cần in:", "In Hợp Đồng",
					JOptionPane.PLAIN_MESSAGE);

			if (maHopDong == null || maHopDong.trim().isEmpty())
				return;

			try {
				InHopDong.showInHopDong(maHopDong.trim());
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
			}
		});

		// ==================== LOGOUT & BACK ====================
		JButton logout = new JButton("Logout");
		logout.setBounds(30, 400, 95, 30);
		logout.setBackground(Color.BLACK);
		logout.setForeground(Color.WHITE);
		panel1.add(logout);
		logout.addActionListener(e -> {
			new login().login();
			menu.this.dispose();
		});

		JButton back = new JButton("Back");
		back.setBounds(140, 400, 95, 30);
		back.setBackground(Color.BLACK);
		back.setForeground(Color.WHITE);
		panel1.add(back);

		getContentPane().setBackground(Color.WHITE);
		setLayout(null);
		setSize(1950, 1090);
		setVisible(true);
	}

	public static void main(String[] args) {
		menu mn = new menu();
		mn.Reception();
	}
}