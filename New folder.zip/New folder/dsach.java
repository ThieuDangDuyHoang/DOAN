package doan1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class dsach extends JFrame implements ActionListener {

	JTable table;
	DefaultTableModel model;

	JButton refreshBtn, closeBtn, searchBtn;
	JTextField searchText;

	public dsach() {

		setTitle("Danh sách Khách Thuê");
		setSize(1000, 600);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// ================= PANEL CHÍNH =================
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(new Color(245, 245, 245));

		// ================= PANEL TRÊN =================
		JPanel topPanel = new JPanel(new BorderLayout());
		topPanel.setBackground(new Color(245, 245, 245));

		// ===== TIÊU ĐỀ =====
		JLabel title = new JLabel("DANH SÁCH KHÁCH THUÊ", SwingConstants.CENTER);
		title.setFont(new Font("Tahoma", Font.BOLD, 24));
		title.setForeground(new Color(0, 102, 204));
		title.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));

		topPanel.add(title, BorderLayout.NORTH);

		// ===== PANEL TÌM KIẾM =====
		JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		searchPanel.setBackground(new Color(245, 245, 245));

		JLabel searchLabel = new JLabel("Tìm kiếm (Mã khách hoặc Họ tên): ");
		searchLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));

		searchPanel.add(searchLabel);

		searchText = new JTextField(20);
		searchText.setFont(new Font("Tahoma", Font.PLAIN, 14));
		searchPanel.add(searchText);

		// Tìm kiếm realtime khi gõ
		searchText.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				String keyword = searchText.getText().trim();
				loadData(keyword);
			}
		});

		// ===== NÚT TÌM KIẾM =====
		searchBtn = new JButton("Tìm kiếm");
		searchBtn.setBackground(new Color(0, 153, 255));
		searchBtn.setForeground(Color.WHITE);
		searchBtn.setFont(new Font("Tahoma", Font.BOLD, 13));
		searchBtn.addActionListener(this);

		searchPanel.add(searchBtn);

		// ===== NÚT LÀM MỚI =====
		refreshBtn = new JButton("Làm mới");
		refreshBtn.setBackground(new Color(0, 204, 102));
		refreshBtn.setForeground(Color.WHITE);
		refreshBtn.setFont(new Font("Tahoma", Font.BOLD, 13));
		refreshBtn.addActionListener(this);

		searchPanel.add(refreshBtn);

		topPanel.add(searchPanel, BorderLayout.SOUTH);

		panel.add(topPanel, BorderLayout.NORTH);

		// ================= BẢNG DỮ LIỆU =================
		model = new DefaultTableModel();

		String[] columns = { "Mã Khách", "Họ Tên", "Ngày Sinh", "SĐT", "Email", "Địa Chỉ", "Mã Phòng" };

		for (String col : columns) {
			model.addColumn(col);
		}

		table = new JTable(model);

		table.setRowHeight(25);
		table.setFont(new Font("Tahoma", Font.PLAIN, 14));
		table.getTableHeader().setFont(new Font("Tahoma", Font.BOLD, 14));
		table.getTableHeader().setBackground(new Color(0, 102, 204));
		table.getTableHeader().setForeground(Color.WHITE);

		JScrollPane scrollPane = new JScrollPane(table);

		panel.add(scrollPane, BorderLayout.CENTER);

		// ================= PANEL DƯỚI =================
		JPanel bottomPanel = new JPanel();
		bottomPanel.setBackground(new Color(245, 245, 245));

		closeBtn = new JButton("Đóng");
		closeBtn.setBackground(Color.RED);
		closeBtn.setForeground(Color.WHITE);
		closeBtn.setFont(new Font("Tahoma", Font.BOLD, 13));
		closeBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				menu m = new menu();
				m.Reception();
				dispose();
			}
		});

		bottomPanel.add(closeBtn);

		panel.add(bottomPanel, BorderLayout.SOUTH);

		add(panel);

		// Load dữ liệu ban đầu
		loadData("");

		setVisible(true);
	}

	// ================= HÀM LOAD DỮ LIỆU =================
	private void loadData(String keyword) {

		model.setRowCount(0);

		try {

			database db = new database();

			String query;

			// Nếu không nhập từ khóa
			if (keyword.isEmpty()) {

				query = "SELECT MaKhach, HoTen, NgaySinh, SoDienThoai, Email, DiaChi, MaPhong "
						+ "FROM KhachThue ORDER BY MaKhach";

				PreparedStatement pst = db.connection.prepareStatement(query);

				ResultSet rs = pst.executeQuery();

				while (rs.next()) {

					Object[] row = { rs.getString("MaKhach"), rs.getString("HoTen"), rs.getString("NgaySinh"),
							rs.getString("SoDienThoai"), rs.getString("Email"), rs.getString("DiaChi"),
							rs.getString("MaPhong") };

					model.addRow(row);
				}

			}
			// Nếu có từ khóa tìm kiếm
			else {

				query = "SELECT MaKhach, HoTen, NgaySinh, SoDienThoai, Email, DiaChi, MaPhong " + "FROM KhachThue "
						+ "WHERE MaKhach LIKE ? OR HoTen LIKE ? " + "ORDER BY MaKhach";

				PreparedStatement pst = db.connection.prepareStatement(query);

				String search = "%" + keyword + "%";

				pst.setString(1, search);
				pst.setString(2, search);

				ResultSet rs = pst.executeQuery();

				while (rs.next()) {

					Object[] row = { rs.getString("MaKhach"), rs.getString("HoTen"), rs.getString("NgaySinh"),
							rs.getString("SoDienThoai"), rs.getString("Email"), rs.getString("DiaChi"),
							rs.getString("MaPhong") };

					model.addRow(row);
				}
			}

		} catch (Exception e) {

			e.printStackTrace();

			JOptionPane.showMessageDialog(this, "Lỗi tải dữ liệu: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
		}
	}

	// ================= XỬ LÝ SỰ KIỆN =================
	@Override
	public void actionPerformed(ActionEvent e) {

		// ===== NÚT TÌM KIẾM =====
		if (e.getSource() == searchBtn) {

			String keyword = searchText.getText().trim();

			loadData(keyword);
		}

		// ===== NÚT LÀM MỚI =====
		else if (e.getSource() == refreshBtn) {

			searchText.setText("");

			loadData("");
		}

		// ===== NÚT ĐÓNG =====
		else if (e.getSource() == closeBtn) {

			dispose();
		}
	}

	// ================= MAIN =================
	public static void main(String[] args) {

		new dsach();
	}
}