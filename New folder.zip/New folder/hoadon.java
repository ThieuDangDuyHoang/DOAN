package doan1;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class hoadon extends JFrame implements ActionListener {

	JTextField ngayThanhToanText, soTienText;
	Choice maHopDongCho, loaiPhiCho;
	JLabel maThanhToanValue; // Hiển thị mã thanh toán tự sinh
	JButton submit, cancel;

	hoadon() {
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(245, 245, 245));
		add(panel);

		JLabel heading = new JLabel("Thanh toán tiền phòng");
		heading.setBounds(120, 10, 300, 30);
		heading.setFont(new Font("Tahoma", Font.BOLD, 20));
		panel.add(heading);

		// ================== MÃ THANH TOÁN TỰ ĐỘNG ==================
		JLabel maThanhToanLabel = new JLabel("Mã thanh toán");
		maThanhToanLabel.setBounds(50, 60, 120, 20);
		panel.add(maThanhToanLabel);

		maThanhToanValue = new JLabel(generateThanhToanID());
		maThanhToanValue.setBounds(180, 60, 180, 20);
		maThanhToanValue.setFont(new Font("Tahoma", Font.BOLD, 14));
		maThanhToanValue.setForeground(new Color(0, 102, 204));
		panel.add(maThanhToanValue);
		// ===========================================================

		JLabel maHopDongLabel = new JLabel("Mã hợp đồng");
		maHopDongLabel.setBounds(50, 100, 120, 20);
		panel.add(maHopDongLabel);

		maHopDongCho = new Choice();
		try {
			database c = new database();
			ResultSet rs = c.statement.executeQuery("SELECT MaHopDong FROM hopdong");
			while (rs.next()) {
				maHopDongCho.add(rs.getString("MaHopDong"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Lỗi tải danh sách hợp đồng!");
		}
		maHopDongCho.setBounds(180, 100, 180, 20);
		panel.add(maHopDongCho);

		JLabel ngayThanhToanLabel = new JLabel("Ngày thanh toán");
		ngayThanhToanLabel.setBounds(50, 140, 120, 20);
		panel.add(ngayThanhToanLabel);
		ngayThanhToanText = new JTextField();
		ngayThanhToanText.setBounds(180, 140, 180, 20);
		panel.add(ngayThanhToanText);

		JLabel soTienLabel = new JLabel("Số tiền (VNĐ)");
		soTienLabel.setBounds(50, 180, 120, 20);
		panel.add(soTienLabel);
		soTienText = new JTextField();
		soTienText.setBounds(180, 180, 180, 20);
		panel.add(soTienText);

		JLabel loaiPhiLabel = new JLabel("Loại phí");
		loaiPhiLabel.setBounds(50, 220, 120, 20);
		panel.add(loaiPhiLabel);
		loaiPhiCho = new Choice();
		loaiPhiCho.add("Tiền phòng");
		loaiPhiCho.add("Điện");
		loaiPhiCho.add("Nước");
		loaiPhiCho.add("Internet");
		loaiPhiCho.add("Khác");
		loaiPhiCho.setBounds(180, 220, 180, 20);
		panel.add(loaiPhiCho);

		submit = new JButton("Submit");
		submit.setBounds(80, 270, 100, 30);
		submit.setBackground(Color.black);
		submit.setForeground(Color.white);
		submit.addActionListener(this);
		panel.add(submit);

		cancel = new JButton("Cancel");
		cancel.setBounds(220, 270, 100, 30);
		cancel.setBackground(Color.black);
		cancel.setForeground(Color.white);
		cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				menu m = new menu();
				m.Reception();
				hoadon.this.dispose();

			}
		});
		panel.add(cancel);

		setLayout(new BorderLayout());
		add(panel, "Center");
		setSize(520, 380);
		setLocation(400, 150);
		setVisible(true);
	}

	// Hàm sinh mã thanh toán tự động
	private String generateThanhToanID() {
		Random rand = new Random();
		int number = rand.nextInt(999999);
		return String.format("TT%06d", number);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == submit) {
			String sMaThanhToan = maThanhToanValue.getText();
			String sMaHopDong = maHopDongCho.getSelectedItem();
			String sNgayThanhToan = ngayThanhToanText.getText();
			String sSoTien = soTienText.getText();
			String sLoaiPhi = loaiPhiCho.getSelectedItem();
			String sTrangThai = "Chưa thanh toán";

			String query = "INSERT INTO ThanhToan (MaThanhToan, MaHopDong, NgayThanhToan, SoTien, LoaiPhi, TrangThai) "
					+ "VALUES('" + sMaThanhToan + "','" + sMaHopDong + "','" + sNgayThanhToan + "'," + sSoTien + ",'"
					+ sLoaiPhi + "','" + sTrangThai + "')";

			try {
				database c = new database();
				c.statement.executeUpdate(query);
				JOptionPane.showMessageDialog(null,
						"Thanh toán đã được ghi thành công!\nMã thanh toán: " + sMaThanhToan);
				setVisible(false);
			} catch (Exception ex) {
				ex.printStackTrace();
				JOptionPane.showMessageDialog(null, "Lỗi khi lưu thanh toán:\n" + ex.getMessage());
			}
		} else {
			setVisible(false);
		}
	}

	public static void main(String[] args) {
		new hoadon();
	}
}