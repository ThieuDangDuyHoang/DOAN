package doan1;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class hopdong extends JFrame implements ActionListener {

	JTextField ngayBatDauText, ngayKetThucText, dieuKhoanText, soThangText;
	JLabel maHopDongValue;
	Choice maPhongCho, maKhachCho;
	JButton submit, cancel;

	hopdong() {
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(245, 245, 245));
		add(panel);

		JLabel heading = new JLabel("Thông tin hợp đồng");
		heading.setBounds(140, 10, 300, 30);
		heading.setFont(new Font("Tahoma", Font.BOLD, 20));
		panel.add(heading);

		// MÃ HỢP ĐỒNG
		JLabel maHopDongLabel = new JLabel("Mã hợp đồng");
		maHopDongLabel.setBounds(50, 60, 120, 20);
		panel.add(maHopDongLabel);

		maHopDongValue = new JLabel(generateContractID());
		maHopDongValue.setBounds(180, 60, 180, 20);
		maHopDongValue.setFont(new Font("Tahoma", Font.BOLD, 14));
		maHopDongValue.setForeground(new Color(0, 102, 204));
		panel.add(maHopDongValue);

		// Mã phòng
		JLabel maPhongLabel = new JLabel("Mã phòng");
		maPhongLabel.setBounds(50, 100, 120, 20);
		panel.add(maPhongLabel);

		maPhongCho = new Choice();
		try {
			database c = new database();
			ResultSet rs = c.statement.executeQuery("SELECT MaPhong FROM Phong");
			while (rs.next()) {
				maPhongCho.add(rs.getString("MaPhong"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		maPhongCho.setBounds(180, 100, 180, 20);
		panel.add(maPhongCho);

		// Mã khách
		JLabel maKhachLabel = new JLabel("Mã khách");
		maKhachLabel.setBounds(50, 140, 120, 20);
		panel.add(maKhachLabel);

		maKhachCho = new Choice();
		try {
			database c = new database();
			ResultSet rs = c.statement.executeQuery("SELECT MaKhach FROM KhachThue");
			while (rs.next()) {
				maKhachCho.add(rs.getString("MaKhach"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		maKhachCho.setBounds(180, 140, 180, 20);
		panel.add(maKhachCho);

		// Ngày bắt đầu
		JLabel ngayBatDauLabel = new JLabel("Ngày bắt đầu");
		ngayBatDauLabel.setBounds(50, 180, 120, 20);
		panel.add(ngayBatDauLabel);
		ngayBatDauText = new JTextField();
		ngayBatDauText.setBounds(180, 180, 180, 20);
		panel.add(ngayBatDauText);

		// Ngày kết thúc
		JLabel ngayKetThucLabel = new JLabel("Ngày kết thúc");
		ngayKetThucLabel.setBounds(50, 220, 120, 20);
		panel.add(ngayKetThucLabel);
		ngayKetThucText = new JTextField();
		ngayKetThucText.setBounds(180, 220, 180, 20);
		panel.add(ngayKetThucText);

		// Số tháng
		JLabel soThangLabel = new JLabel("Số tháng");
		soThangLabel.setBounds(50, 260, 120, 20);
		panel.add(soThangLabel);
		soThangText = new JTextField();
		soThangText.setBounds(180, 260, 180, 20);
		panel.add(soThangText);

		// Điều khoản
		JLabel dieuKhoanLabel = new JLabel("Điều khoản");
		dieuKhoanLabel.setBounds(50, 300, 120, 20);
		panel.add(dieuKhoanLabel);
		dieuKhoanText = new JTextField();
		dieuKhoanText.setBounds(180, 300, 280, 20);
		panel.add(dieuKhoanText);

		submit = new JButton("Submit");
		submit.setBounds(100, 350, 100, 30);
		submit.setBackground(Color.black);
		submit.setForeground(Color.white);
		submit.addActionListener(this);
		panel.add(submit);

		// ================== NÚT CANCEL ĐÃ SỬA ==================
		cancel = new JButton("Cancel");
		cancel.setBounds(230, 350, 100, 30);
		cancel.setBackground(Color.black);
		cancel.setForeground(Color.white);
		cancel.addActionListener(e -> {
			menu m = new menu();
			m.Reception();// Mở menu
			dispose(); // Đóng form hiện tại
		});
		panel.add(cancel);
		// ======================================================

		setLayout(new BorderLayout());
		add(panel, "Center");
		setSize(520, 430);
		setLocation(400, 150);
		setVisible(true);
	}

	private String generateContractID() {
		Random rand = new Random();
		int number = rand.nextInt(999999);
		return String.format("HD%06d", number);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == submit) {
			String sMaHopDong = maHopDongValue.getText();
			String sMaPhong = maPhongCho.getSelectedItem();
			String sMaKhach = maKhachCho.getSelectedItem();
			String sNgayBatDau = ngayBatDauText.getText();
			String sNgayKetThuc = ngayKetThucText.getText();
			String sSoThang = soThangText.getText();
			String sDieuKhoan = dieuKhoanText.getText();

			String query = "INSERT INTO hopdong (MaHopDong, MaPhong, MaKhach, DieuKhoan, SoThang) " + "VALUES('"
					+ sMaHopDong + "','" + sMaPhong + "','" + sMaKhach + "','" + sDieuKhoan + "'," + sSoThang + ")";

			try {
				database c = new database();
				c.statement.executeUpdate(query);
				JOptionPane.showMessageDialog(null, "Hợp đồng đã được lưu thành công!\nMã: " + sMaHopDong);
				dispose(); // Đóng form sau khi lưu thành công
			} catch (Exception ex) {
				ex.printStackTrace();
				JOptionPane.showMessageDialog(null, "Lỗi khi lưu:\n" + ex.getMessage());
			}
		}
	}

	public static void main(String[] args) {
		new hopdong();
	}
}