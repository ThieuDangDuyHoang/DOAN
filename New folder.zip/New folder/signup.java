package doan1;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class signup extends JFrame implements ActionListener {
	private JTextField nameField, usernameField;
	private JTextField passwordField;
	private JButton SignupButton, ExitButton;

	signup() {
		setTitle("Đăng kí Admin");
		setSize(600, 400);
		setLocation(500, 200);
		setLayout(null);
		getContentPane().setBackground(Color.white);

		ImageIcon icon = new ImageIcon("D:/ảnh/signup.jpg");
		Image scaledImage = icon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH);
		JLabel anh = new JLabel(new ImageIcon(scaledImage));
		anh.setBounds(300, 30, 250, 270);
		add(anh);

		JLabel nameLabel = new JLabel("Tên:");
		nameLabel.setBounds(30, 50 + 40, 125, 20);
		add(nameLabel);

		nameField = new JTextField();
		nameField.setBounds(170, 50 + 40, 125, 20);
		add(nameField);

		JLabel userLabel = new JLabel("Username:");
		userLabel.setBounds(30, 100 + 40, 125, 20);
		add(userLabel);

		usernameField = new JTextField();
		usernameField.setBounds(170, 100 + 40, 125, 20);
		add(usernameField);

		JLabel passLabel = new JLabel("Password:");
		passLabel.setBounds(30, 150 + 40, 125, 20);
		add(passLabel);

		passwordField = new JTextField();
		passwordField.setBounds(170, 150 + 40, 125, 20);
		add(passwordField);

		SignupButton = new JButton("Đăng Ký");
		SignupButton.setBounds(50, 300 - 40, 120, 25);
		add(SignupButton);

		ExitButton = new JButton("Thoát");
		ExitButton.setBounds(200, 300 - 40, 100, 25);
		add(ExitButton);

		SignupButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String name = nameField.getText();
				String username = usernameField.getText();
				String pass = passwordField.getText();

				if (name.isEmpty() || username.isEmpty() || pass.isEmpty()) {
					JOptionPane.showMessageDialog(signup.this, "Vui lòng nhập đầy đủ thông tin!", "Lỗi nhập liệu",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {
					Connection conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;"
							+ "databaseName=DOAN1;" + "integratedSecurity=true;" + "encrypt=false;");
					String sql = "INSERT INTO Users (Ten,username,pass) VALUES (?,?,?)";
					PreparedStatement sta = conn.prepareStatement(sql);
					sta.setString(1, name);
					sta.setString(2, username);
					sta.setString(3, pass);
					sta.executeUpdate();
					JOptionPane.showMessageDialog(null, "Đăng Ký Thành Công");
				} catch (Exception ex) {
					// TODO: handle exception

					JOptionPane.showMessageDialog(null, "Lỗi");
				}
				login lq = new login();
				lq.login();
				signup.this.dispose();

			}
		});

		ExitButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				login lg = new login();
				lg.login();
				signup.this.dispose();
			}
		});

		setVisible(true);
	}

	public static void main(String[] args) {
		new signup();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

	public void signup() {
		// TODO Auto-generated method stub

	}
}