package doan1;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class login {
	public void login() {
		JFrame frame = new JFrame("Login");
		frame.setSize(800, 450);
		frame.setLayout(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel p1 = new JPanel();
		p1.setBounds(0, 0, 534, 450);
		p1.setLayout(null);
		p1.setBackground(new Color(204, 255, 255));
		frame.add(p1);

		JPanel p2 = new JPanel();
		p2.setBounds(534, 0, 250, 450);
		p2.setBackground(new Color(245, 245, 220));
		p2.setLayout(null);
		frame.add(p2);

		JPanel p3 = new JPanel();
		p3.setBounds(0, 7, 534, 90);
		p3.setLayout(null);
		p3.setBackground(new Color(204, 255, 255));
		p1.add(p3);

		ImageIcon icon2 = new ImageIcon("D:/Ảnh/pic2.png");
		Image img2 = icon2.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
		icon2 = new ImageIcon(img2);
		JLabel label2 = new JLabel(icon2);
		label2.setBounds(0, 0, p3.getWidth(), p3.getHeight());
		p3.add(label2);

		ImageIcon icon = new ImageIcon("D:/Ảnh/pic.jpg");
		Image img = icon.getImage().getScaledInstance(p2.getWidth(), p2.getHeight(), Image.SCALE_SMOOTH);
		icon = new ImageIcon(img);
		JLabel label = new JLabel(icon);
		label.setBounds(0, 0, p2.getWidth(), p2.getHeight());

		JLabel lblUser = new JLabel("Tên đăng nhập:");
		lblUser.setBounds(50, 130, 150, 25);
		lblUser.setFont(new Font("Arial", Font.BOLD, 20));
		JTextField txtUser = new JTextField();
		txtUser.setBounds(240, 130, 200, 30);

		JLabel lblPass = new JLabel("Mật khẩu:");
		lblPass.setBounds(50, 180, 120, 25);
		lblPass.setFont(new Font("Arial", Font.BOLD, 20));
		JPasswordField txtPass = new JPasswordField();
		txtPass.setBounds(240, 180, 200, 30);

		JButton btnLogin = new JButton("Đăng nhập");
		btnLogin.setBounds(120, 240 + 30, 120, 30);

		JButton btnRegister = new JButton("Đăng ký");
		btnRegister.setBounds(260, 240 + 30, 120, 30);

		JButton btnForgot = new JButton("Quên mật khẩu");
		btnForgot.setBounds(160, 300 + 30, 180, 30);

		p1.add(lblUser);
		p1.add(txtUser);
		p1.add(lblPass);
		p1.add(txtPass);
		p1.add(btnLogin);
		p1.add(btnRegister);
		p1.add(btnForgot);

		p2.add(label);
		btnRegister.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				signup su = new signup();
				su.signup();
				frame.dispose();
			}
		});

		btnLogin.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					Connection conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;"
							+ "databaseName=DOAN1;" + "integratedSecurity=true;" + "encrypt=false;");
					String sql = "SELECT * FROM Users WHERE username=? and pass=?";
					PreparedStatement sta = conn.prepareStatement(sql);
					sta.setString(1, txtUser.getText().trim());
					sta.setString(2, new String(txtPass.getPassword()).trim());
					ResultSet rs = sta.executeQuery();
					if (rs.next()) {
						JOptionPane.showMessageDialog(frame, "Đăng Nhập Thành Công");
						frame.dispose();
						//
						//

					} else {
						JOptionPane.showMessageDialog(frame, "Sai tài khoản hoặc mật khẩu vui lòng thử lại sau");
					}
				} catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(frame, "Đăng Nhập Không Thành Công");
				}
			}
		});

		frame.setVisible(true);
	}

	public static void main(String[] args) {
		login l = new login();
		l.login();
	}
}
